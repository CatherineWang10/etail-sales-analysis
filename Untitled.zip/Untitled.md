```python
# 导入需要的库
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 加载CSV文件
df = pd.read_csv(r"C:/Users/26/Desktop/Retail and wherehouse Sale.csv")

# 查看数据的前几行，检查数据结构
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>YEAR</th>
      <th>MONTH</th>
      <th>SUPPLIER</th>
      <th>ITEM CODE</th>
      <th>ITEM DESCRIPTION</th>
      <th>ITEM TYPE</th>
      <th>RETAIL SALES</th>
      <th>RETAIL TRANSFERS</th>
      <th>WAREHOUSE SALES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2020</td>
      <td>1</td>
      <td>REPUBLIC NATIONAL DISTRIBUTING CO</td>
      <td>100009</td>
      <td>BOOTLEG RED - 750ML</td>
      <td>WINE</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2020</td>
      <td>1</td>
      <td>PWSWN INC</td>
      <td>100024</td>
      <td>MOMENT DE PLAISIR - 750ML</td>
      <td>WINE</td>
      <td>0.00</td>
      <td>1.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2020</td>
      <td>1</td>
      <td>RELIABLE CHURCHILL LLLP</td>
      <td>1001</td>
      <td>S SMITH ORGANIC PEAR CIDER - 18.7OZ</td>
      <td>BEER</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2020</td>
      <td>1</td>
      <td>LANTERNA DISTRIBUTORS INC</td>
      <td>100145</td>
      <td>SCHLINK HAUS KABINETT - 750ML</td>
      <td>WINE</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2020</td>
      <td>1</td>
      <td>DIONYSOS IMPORTS INC</td>
      <td>100293</td>
      <td>SANTORINI GAVALA WHITE - 750ML</td>
      <td>WINE</td>
      <td>0.82</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 数据概览
df.info()

# 查看统计信息
df.describe()

# 检查缺失值
df.isnull().sum()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 30000 entries, 0 to 29999
    Data columns (total 9 columns):
     #   Column            Non-Null Count  Dtype  
    ---  ------            --------------  -----  
     0   YEAR              30000 non-null  int64  
     1   MONTH             30000 non-null  int64  
     2   SUPPLIER          29967 non-null  object 
     3   ITEM CODE         30000 non-null  object 
     4   ITEM DESCRIPTION  30000 non-null  object 
     5   ITEM TYPE         30000 non-null  object 
     6   RETAIL SALES      29999 non-null  float64
     7   RETAIL TRANSFERS  30000 non-null  float64
     8   WAREHOUSE SALES   30000 non-null  float64
    dtypes: float64(3), int64(2), object(4)
    memory usage: 2.1+ MB
    




    YEAR                 0
    MONTH                0
    SUPPLIER            33
    ITEM CODE            0
    ITEM DESCRIPTION     0
    ITEM TYPE            0
    RETAIL SALES         1
    RETAIL TRANSFERS     0
    WAREHOUSE SALES      0
    dtype: int64




```python
# 用 'Unknown' 填充 SUPPLIER 列的缺失值
df['SUPPLIER'] = df['SUPPLIER'].fillna('Unknown')
```


```python
# 用中位数填充 RETAIL SALES 列的缺失值
df['RETAIL SALES'] = df['RETAIL SALES'].fillna(df['RETAIL SALES'].median())
```


```python
# 检查缺失值
df.isnull().sum()
```




    YEAR                0
    MONTH               0
    SUPPLIER            0
    ITEM CODE           0
    ITEM DESCRIPTION    0
    ITEM TYPE           0
    RETAIL SALES        0
    RETAIL TRANSFERS    0
    WAREHOUSE SALES     0
    dtype: int64




```python
# 销售额的分布
sns.histplot(df['RETAIL SALES'], kde=True)
plt.title('Retail Sales Distribution')
plt.xlabel('Retail Sales')
plt.ylabel('Frequency')
plt.show()
```


    
![png](output_5_0.png)
    



```python
# 产品类型与销售额关系
plt.figure(figsize=(10, 6))
sns.boxplot(x='ITEM TYPE', y='RETAIL SALES', data=df)
plt.title('Retail Sales by Item Type')
plt.xlabel('Item Type')
plt.ylabel('Retail Sales')
plt.xticks(rotation=45)
plt.show()
```


    
![png](output_6_0.png)
    



```python
# 按供应商分析销售额
plt.figure(figsize=(12, 6))
sns.boxplot(x='SUPPLIER', y='RETAIL SALES', data=df)
plt.title('Retail Sales by Supplier')
plt.xlabel('Supplier')
plt.ylabel('Retail Sales')
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_7_0.png)
    



```python
# 按年和月汇总销售数据
df['Date'] = pd.to_datetime(df[['YEAR', 'MONTH']].assign(DAY=1))  # 创建日期
monthly_sales = df.groupby(df['Date'].dt.to_period('M'))['RETAIL SALES'].sum()

# 绘制销售趋势图
monthly_sales.plot(kind='line', figsize=(12, 6))
plt.title('Monthly Retail Sales Over Time')
plt.xlabel('Month')
plt.ylabel('Retail Sales')
plt.xticks(rotation=45)
plt.show()
```


    
![png](output_8_0.png)
    



```python
# 按年和月汇总销售数据
df['Date'] = pd.to_datetime(df[['YEAR', 'MONTH']].assign(DAY=1))  # 创建日期
monthly_sales = df.groupby(df['Date'].dt.to_period('M'))['RETAIL SALES'].sum()

# 绘制销售趋势图
plt.figure(figsize=(12, 6))
monthly_sales.plot(kind='line', color='green')
plt.title('Monthly Retail Sales Over Time')
plt.xlabel('Month')
plt.ylabel('Retail Sales')
plt.xticks(rotation=45)
plt.grid(True)
plt.show()
```


    
![png](output_9_0.png)
    



```python

```
